//
//  ViewController.swift
//  ApplePie
//
//  Created by Nada Khaled on 27/08/2024.
//p

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var ScoreLabel: UILabel!
    @IBOutlet weak var CorrectWordLabel: UILabel!
    @IBOutlet weak var treeImageView: UIImageView!
    
    @IBAction func ButtonPressed(_ sender: UIButton) {
        sender.isEnabled = false
        let letterString = sender.title(for: .normal)!
            let letter = Character(letterString.lowercased())
            currentGame.playerGuessed(letter: letter)
            updateGameState()    }
    
    
    @IBOutlet var LetterCollection: [UIButton]!
    
    var listOfWords = ["buccaneer", "swift", "glorious", "incandescent", "bug", "program"]
    let incorrectMovesAllowed = 7
    var totalWins = 0 {
        didSet{
            newRound()
        }
    }
    var totalLosses = 0 {
        didSet{
            newRound()
        }
    }
    var currentGame: Game!


    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        newRound()
        
    }
    


    func newRound() {
        if !listOfWords.isEmpty {
            let newWord = listOfWords.removeFirst()
            currentGame = Game(Word: newWord, incorrectMoveRemining: incorrectMovesAllowed, guessedLetters: [])
            enableLetterButtons(true)
            updateUI()
        } else {
            enableLetterButtons(false)
        }
    }

    func enableLetterButtons(_ enable: Bool) {
        for button in LetterCollection {
            button.isEnabled = enable
        }
    }

    func updateUI() {
        var letters = [String]()
        for letter in currentGame.formattedWord {
            letters.append(String(letter))
        }
        _ = letters.joined(separator: " ")
        ScoreLabel.text = "Wins: \(totalWins), Losses: \(totalLosses)"
             treeImageView.image = UIImage(named: "Tree \(currentGame.incorrectMoveRemining)")
    }
    
    func updateGameState(){
        if currentGame.incorrectMoveRemining == 0 {
            totalLosses += 1
            
        } else if currentGame.Word == currentGame.formattedWord{
            totalWins += 1
        }else{
            updateUI()        }
        
        
    }
}

