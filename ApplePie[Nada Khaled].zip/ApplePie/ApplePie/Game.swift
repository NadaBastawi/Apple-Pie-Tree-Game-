//
//  Game.swift
//  ApplePie
//
//  Created by Nada Khaled on 27/08/2024.
//

import Foundation
struct Game {
    var Word : String
    var incorrectMoveRemining : Int
    var guessedLetters : [Character]
    var formattedWord: String {
        var guessedWord = ""
        for letter in Word {
            if guessedLetters.contains(letter) {
                guessedWord += "\(letter)"
            } else {
                guessedWord += "_"
            }
        }
        return guessedWord
    }
    
    mutating func playerGuessed(letter: Character) {
        guessedLetters.append(letter)
        if !Word.contains(letter) {
            incorrectMoveRemining -= 1
            }
    }}
